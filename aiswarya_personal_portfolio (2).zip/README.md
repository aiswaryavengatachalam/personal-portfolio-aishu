# Aiswarya — Personal Developer Portfolio

A responsive personal portfolio website built with semantic HTML5, CSS Flexbox, CSS Grid, and a small JavaScript mobile navigation toggle.

## Files
- `index.html` — page structure and content
- `style.css` — responsive styling, Flexbox, and Grid layouts
- `script.js` — mobile navigation interaction

## Run locally
Open `index.html` in a web browser.

## Before publishing
1. Replace `your.email@example.com` with your real email address.
2. Replace `your-username` in the GitHub URL with your GitHub username.
3. Replace `your-linkedin-id` with your LinkedIn profile ID.
4. Edit the skills and project descriptions so they accurately reflect your own experience.
5. Add a profile photo only if you want one; the current design uses a CSS monogram.

## Publish with GitHub Pages
1. Create a GitHub repository (for example, `personal-portfolio`).
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then save.
6. Wait for the Pages deployment and open the published URL shown on that page.
